# Results

Every `.jsonl` file holds one JSON object per input (a buggy submission), keyed by `example_id`
(`<problem>:<student>:S<position>`). Student programs are not included; `python run.py build-data` recreates them in `data/`.

```text
|-output
    |-benchmark
    |    |-rq1-inputs.jsonl
    |    |-rq1-student-steps.jsonl
    |    |-never-accepted-steps.jsonl
    |    |-canonical-inputs.jsonl
    |    |-canonical-student-steps.jsonl
    |    |-java-inputs.jsonl
    |    |-corpus.json
    |-approaches
    |    |-zpdpatch.jsonl
    |    |-refactory.jsonl
    |    |-brafar.jsonl
    |    |-mentored.jsonl
    |    |-lsgen.jsonl
    |    |-lsgen-qwen.jsonl
    |-rules
    |    |-rq1/{strict,progress,progress-prefix,selected,base-three-samples}.jsonl
    |    |-rq1/selection.json
    |-differential
    |    |-{zpdpatch,refactory,brafar,mentored,lsgen-qwen,lsgen}.jsonl
    |    |-students.json
    |-selection
    |    |-{Answer,Progress,Strict}{2027,2028,2029}.jsonl
    |-targets
    |    |-{seen,unseen,java}/{answer,progress}.jsonl
    |    |-{seen,unseen}/progress-{same-user,cross-user}.jsonl
    |-ablation
    |    |-{seen,unseen}/{zpdpatch,no-training,sampled,one-checkpoint,same-checkpoint,distinct-checkpoints,history}.jsonl
    |-generality
         |-scale-1.5b/{seen,unseen}/{one-checkpoint,zpdpatch}.jsonl
         |-java-students/{one-checkpoint,zpdpatch}.jsonl
         |-java-exercises/{one-checkpoint,zpdpatch}.jsonl
         |-prefix/{seen,unseen}/{one-checkpoint,zpdpatch}.jsonl
```

> benchmark : The inputs' sizes and verdicts, the same problems' trajectories that never reach acceptance (`never-accepted-steps`: each distinct submission's verdict and pass rate and each step's class, kept when the test suite reproduces every recorded verdict), the students' own steps (`step_ted` in AST edit operations, `step_token_retention`, `step_line_retention`, and each step's verdicts, pass rates, and `step_class`), and the corpus counts. No source code.  
> approaches : RQ1 and RQ2. ZPDPatch and the five existing configurations on the 1,753 inputs of the 14-problem benchmark.  
> rules : RQ1 inputs. Strict and Progress portfolios trained with current-only prompts, Progress trained with retained prefixes, the portfolio Select chooses among all nine current-only checkpoints (`selection.json`), and three samples of the untrained base model at temperature 0.8.  
> differential : Every plausible RQ1 patch on 100 generated inputs per problem, judged against the majority output of seven accepted programs: `patch_fails`, `own_fails` (the student's own accepted program fails an input), and `beyond_own` (the patch fails an input that program passes); `_wa_re` counts only wrong answers and runtime errors, `_rechecked` reruns time-outs once.  
> selection : The nine checkpoints on the 461 validation inputs, from which Select chooses the portfolio.  
> targets : RQ3 (target source). The Answer and Progress rules trained on the same number of examples; `progress-cross-user` replaces each Progress target with another student's submission with the same execution outcomes.  
> ablation : RQ3. Each variant and the ZPDPatch configuration it is compared with (`sampled` draws three candidates from one checkpoint at temperature 0.8, the reference of `no-training`).  
> generality : RQ4. One checkpoint and the portfolio for the 1.5B model and for Java with students or exercises held out; `prefix` repairs every earlier submission of a trajectory (`trajectory_phase`).  

## Fields

| Field | Meaning |
| --- | --- |
| `repaired` | the returned program passes every test and differs from the submission |
| `buggy_pass_rate`, `fixed_pass_rate` | fraction of tests the submission and the returned program pass |
| `ted_buggy_fixed` | AST edit operations between the submission and a repaired return (null if either does not parse) |
| `token_retention`, `line_retention` | share of the submission's tokens and non-empty lines the return keeps |
| `generated_code` | the returned program (null when it is the submission itself) |
| `step_class` | a return against the submission: `AC`, `forward` (a less severe verdict, or the same verdict with no test case worse and one better), `sideways`, or `regress`; null for the submission itself |
| `ted_buggy_returned`, `ted_returned_accepted` | for a `forward` return, AST edit operations from the submission and to the student's accepted program |
| `selected_source` | the portfolio member whose candidate was returned, or `current-fallback` |
| `training_copy` | the return equals an accepted training program of the same problem |
| `training_ast_copy` | a repair whose AST equals that of an accepted training program of the same problem (RQ1 students held out) |
| `fixed_tc_outcomes` | per-test verdict of the returned program |

MENTORED ran from its public implementation with a budget of one hour and 16 GB per input; 649 of the 1,753 inputs
reached it and count as unrepaired. REFACTORY and BRAFAR ran from their public implementations on the same inputs. LSGen used GPT-4o (`lsgen`) and the base model of ZPDPatch, Qwen2.5-Coder-7B-Instruct
(`lsgen-qwen`).
